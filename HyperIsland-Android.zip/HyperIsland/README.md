# Hyper Island (Android)

Dynamic Island mit Glas-Look - Kotlin + Jetpack Compose.

## Einrichten
1. App öffnen
2. "Bedienungshilfe Hyper Island" aktivieren (Einstellungen > Bedienungshilfen > Heruntergeladene Apps)
3. "Benachrichtigungszugriff" erlauben
4. Ausgegraut? Einstellungen > Apps > Hyper Island > Drei Punkte > Eingeschränkte Einstellungen zulassen
5. Xiaomi/HyperOS: Autostart erlauben, Akku auf "Keine Einschränkungen"

## Bedienung
Tippen = auf/zu, lang drücken = Details, wischen = schließen, Cover/Icon antippen = App öffnen.
Beim Minimieren einer App mit laufender Musik/Anruf zieht sich die Island ein.
