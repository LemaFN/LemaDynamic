package de.lema.hyperisland

import android.app.Notification
import android.app.PendingIntent
import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class Notifs : NotificationListenerService() {
    private var mc: MediaController? = null
    private val h = Handler(Looper.getMainLooper())
    private val cb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) = music()
        override fun onMetadataChanged(metadata: MediaMetadata?) = music()
    }
    private val tick = object : Runnable { override fun run() { music(); h.postDelayed(this, 1000) } }

    private fun go(p: PendingIntent?) { try { p?.send() } catch (_: Exception) {} }

    override fun onListenerConnected() {
        try {
            val m = getSystemService(MediaSessionManager::class.java)
            val cn = ComponentName(this, Notifs::class.java)
            m.addOnActiveSessionsChangedListener({ l -> pick(l) }, cn)
            pick(m.getActiveSessions(cn))
        } catch (_: Exception) {}
        h.post(tick)
    }

    override fun onListenerDisconnected() { h.removeCallbacks(tick); Hub.drop("music") }

    private fun pick(l: List<MediaController>?) {
        mc?.unregisterCallback(cb); mc = l?.firstOrNull(); mc?.registerCallback(cb); music()
    }

    private fun music() {
        val c = mc; val md = c?.metadata; val ps = c?.playbackState
        if (c == null || md == null || ps == null || ps.state == PlaybackState.STATE_STOPPED || ps.state == PlaybackState.STATE_NONE) return Hub.drop("music")
        val pl = ps.state == PlaybackState.STATE_PLAYING
        val t = c.transportControls
        val dur = md.getLong(MediaMetadata.METADATA_KEY_DURATION).coerceAtLeast(1)
        val pos = ps.position + if (pl) ((SystemClock.elapsedRealtime() - ps.lastPositionUpdateTime) * ps.playbackSpeed).toLong() else 0L
        Hub.post(Act("music", "music", md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Musik",
            md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "", (pos.toFloat() / dur).coerceIn(0f, 1f),
            ctl = mapOf("⏮" to { t.skipToPrevious() }, (if (pl) "⏸" else "▶") to { if (pl) t.pause() else t.play() }, "⏭" to { t.skipToNext() })))
    }

    override fun onNotificationPosted(s: StatusBarNotification) {
        val n = s.notification
        if (s.packageName == packageName) return
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (n.category == Notification.CATEGORY_CALL) {
            Hub.post(Act("call", "call", title, "Anruf", ctl = n.actions.orEmpty().associate { a -> a.title.toString() to { go(a.actionIntent) } }))
            return
        }
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0 || n.flags and Notification.FLAG_GROUP_SUMMARY != 0 || n.category == Notification.CATEGORY_TRANSPORT) return
        Hub.post(Act("msg", "msg", title, text, ttl = 6000, ctl = mapOf("Öffnen" to { go(n.contentIntent) })))
    }

    override fun onNotificationRemoved(s: StatusBarNotification) {
        if (s.notification.category == Notification.CATEGORY_CALL) Hub.drop("call")
    }
}
