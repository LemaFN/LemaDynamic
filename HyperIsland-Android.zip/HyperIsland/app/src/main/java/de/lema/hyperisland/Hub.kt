package de.lema.hyperisland

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

data class Act(
    val id: String, val kind: String, val title: String, val sub: String = "",
    val prog: Float = 0f, val ttl: Long = 0, val ctl: Map<String, () -> Unit> = emptyMap(),
    val t0: Long = System.nanoTime()
)

fun pr(k: String) = when (k) { "msg" -> 10; "call" -> 9; "timer" -> 6; "music" -> 5; else -> 3 }
fun ic(k: String) = when (k) { "music" -> "🎵"; "timer" -> "⏱"; "call" -> "📞"; "chg" -> "⚡"; else -> "💬" }

object Hub {
    val acts = MutableStateFlow<List<Act>>(emptyList())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var tj: Job? = null

    fun post(a: Act) {
        acts.update { l -> val o = l.find { it.id == a.id }; l.filter { it.id != a.id } + a.copy(t0 = o?.t0 ?: a.t0) }
        if (a.ttl > 0) scope.launch { delay(a.ttl); drop(a.id) }
    }

    fun drop(id: String) = acts.update { l -> l.filter { it.id != id } }

    fun timer(s: Int) {
        tj?.cancel()
        tj = scope.launch {
            for (i in s downTo 1) {
                post(Act("timer", "timer", "Timer", "%d:%02d".format(i / 60, i % 60), ctl = mapOf("Stopp" to { tj?.cancel(); drop("timer") })))
                delay(1000)
            }
            drop("timer")
            post(Act("tdone", "msg", "Timer", "Abgelaufen!", ttl = 5000))
        }
    }
}
