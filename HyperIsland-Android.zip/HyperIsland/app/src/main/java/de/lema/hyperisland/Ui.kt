package de.lema.hyperisland

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.abs

fun col(k: String) = Color(when (k) { "music" -> 0xFFFA2D55; "timer" -> 0xFFFF9F0A; "call", "chg" -> 0xFF30D158; else -> 0xFF5E9BFF })

@Composable
fun Island() {
    val list by Hub.acts.collectAsState()
    val top = list.maxWithOrNull(compareBy<Act>({ pr(it.kind) }, { it.t0 }))
    var exp by remember { mutableStateOf(false) }
    var drag by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(top?.id) { exp = top?.kind == "msg" || top?.kind == "call" }
    LaunchedEffect(exp, top?.id) { if (exp && top?.kind != "call") { delay(6000); exp = false } }
    if (top == null) return
    val sp = spring<Dp>(0.55f, 380f)
    val w by animateDpAsState(if (exp) 360.dp else 232.dp, sp, label = "w")
    val h by animateDpAsState(if (!exp) 36.dp else if (top.kind == "music") 170.dp else 112.dp, sp, label = "h")
    val r by animateDpAsState(if (exp) 34.dp else 18.dp, sp, label = "r")
    Box(
        Modifier.width(w).height(h).clip(RoundedCornerShape(r)).background(Color.Black)
            .pointerInput(top.id) { detectTapGestures(onTap = { exp = !exp }, onLongPress = { exp = true }) }
            .pointerInput(top.id) {
                detectHorizontalDragGestures(onDragEnd = { if (abs(drag) > 120f) Hub.drop(top.id); drag = 0f }) { _, d -> drag += d }
            }
    ) {
        Crossfade(top.id to exp, label = "c") { (id, e) ->
            val a = list.find { it.id == id }
            if (a != null) { if (e) Expanded(a) else Compact(a) }
        }
    }
}

@Composable
fun Compact(a: Act) = Row(Modifier.fillMaxSize().padding(horizontal = 14.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
    Text(ic(a.kind), fontSize = 15.sp)
    Text(if (a.kind == "music") "♪" else if (a.kind == "msg") a.title else a.sub, color = col(a.kind), fontSize = 13.sp, maxLines = 1)
}

@Composable
fun Expanded(a: Act) = Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(ic(a.kind), fontSize = 28.sp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(a.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(a.sub, color = Color(0xFFA8A8B0), fontSize = 13.sp, maxLines = 2)
        }
    }
    if (a.kind == "music") Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0x33FFFFFF))) {
        Box(Modifier.fillMaxWidth(a.prog).fillMaxHeight().background(Color.White))
    }
    Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly) {
        a.ctl.forEach { (k, f) -> Text(k, Modifier.clickable { f() }.padding(10.dp), color = Color.White, fontSize = 20.sp) }
    }
}
